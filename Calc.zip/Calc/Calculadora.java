package Calc;

public class Calculadora {
    //Definición de atributos 
    int valor1;
    int valor2;

    //Definición de métodos
    
    // Suma de dos números
    public int Suma(int val1, int val2){
        return val1 + val2;
    }

    // Resta de dos números
    public int Resta(int val1, int val2){
        return val1 - val2;
    }
}
